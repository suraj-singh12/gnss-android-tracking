# Issue 48 — revised operator review proposal

Functional and security contracts accepted. Final visual approval pending this one bounded revision. Implementation is NOT AUTHORIZED.

Source: integration/combined-upgrades a38a38e58fc3e0b7132efbdf9073c4a7b6e7f4c5. Canonical guidance: 3b60b6d6228ca208df75765e2008c9b9abba8a69 (identical AGENTS.md). Original work checkout unchanged. Isolated detached analysis worktree: /workspace/issue48-design. #47 has its own devX branch; implementation must re-fetch integration and inspect its approved merge state.

## Visual reference and limitations

Figma REVIEW V3 page 8:2 structure inspected; #39 V4 overrides read (no Pause History Sync, native Sync/Stop notification actions, subdued emergency colors, icon-only theme control). Figma Starter rate limit prevented screenshots, token/component inspection and proposal writes. Attached SVG is a local schematic proposal, not a verified Figma reproduction or Android render. No visual approval is inferred. Existing source uses native scalable text, scrollable pages, semantic Day/Night tokens, 48 dp targets and persistent three-tab navigation. All proposed bodies scroll; no credential survives Activity recreation.

## Final bounded revision — visual review map

This package contains three SVG boards and this document:

- `day-night-states.svg`: the same six states in matched Day/Night treatments. Primary content is limited to state, one short explanation, saved address and relevant actions. Full UUIDs, timestamps, the 30-second rule, canonical rejection reasons and GNSS distinctions appear only in details. “Contact verified” is the compact label for authenticated response evidence; “Contact unavailable” is the compact stale/offline presentation and does not assert a network diagnosis.
- `guided-enrollment.svg`: eight matched Day/Night screens, read left to right within each row: setup entry → compare phone → enter private credential → compare Command ID → explicit authorization → enrolled/waiting → verified response → identity and verification details. Command generation/private transfer is shown in the companion Command board. The authorization stage represents the existing protected confirmation dialog; it does not add a second authorization or pairing mechanism. Details scroll on compact devices; persistent navigation remains outside the scrolling body. “More evidence & rejection reasons” expands within the same details destination. Review authorization validates phone UUID and credential structure using the existing parser; invalid credentials stay on the entry step without binding.
- `command-phone-controls.svg`: existing Live phone controls vocabulary, with neutral bordered surfaces, source CSS typography/color family, 14 px dialog radius, 840 px maximum width, native-shaped controls and a green primary action. Public authority identity, per-phone enrollment and directional authenticated request evidence are separated by alignment and restrained borders. The companion sequence shows existing generation confirmation and private provisioning, without any secret. Recipient selection, all existing instruction-specific fields, alerts, adaptive options and history remain in their existing scrollable owners; the illustrated reporting selection does not remove other controls. The three numbered provisioning stages are storyboard content, not simultaneous nested dialogs or a new page.

All UUIDs, addresses, times and statuses on the boards are synthetic examples. No credential value or encoded credential is embedded. The SVGs are review artifacts, not application screenshots, production source, implementation approval or evidence of pixel fidelity. Command styling was checked against current `command/web/style.css` and its existing Live phone controls markup. Figma visual comparison remains blocked by the previously reported Starter tool limit; no claim of newly inspected Figma pixels is made.

Visible labels are intentionally concise. The detailed freshness/security contracts below remain unchanged; moving explanations into details does not weaken their enforcement. The flow is the existing enrollment process with guided presentation, using the existing credential parser, authorization boundary, Keystore and outbound authenticated exchange. No new authentication engine, credential protocol, auto-pairing or key store is proposed.

## Identity vocabulary — mandatory throughout

`Command ID` always means the persistent Command authority UUID (`authority_id` in existing Command state). It is public, stable across Command restarts with the same state, and is not a credential. `This phone ID` means the separate Android installation device UUID. `Command address` means the configured network endpoint, not identity or proof of trust. `Instruction ID` identifies one remote instruction; it is never called Command ID or Command UUID.

Existing defect identified for correction ONLY after final implementation approval: `commandInstructionDetails` in `CommandPresentation.kt` currently labels `row.id` as `Command UUID`. The proposed label is `Instruction ID`; `row.authority` is the `Command ID`. Screens, Full record, diagnostics and accessibility text must use these meanings consistently. No application correction has been made in this design phase.

## Preserve #39 approval

The existing REVIEW V3 layout and approved V4 overrides remain binding: no Pause History Sync; real native Sync Now and protected Stop Tracking notification actions; consistent subdued crimson/burgundy emergency/error treatment in Day and Night; icon-only persistent Day/Night theme toggle with accessible labels. Preserve existing Settings and Diagnostics destinations, stable Tracking/Sync/SOS placements, native components, typography, spacing, touch targets and responsive scrolling. These schematic mockups propose only Command access content and discoverability; their simplified headers, navigation and geometry do not authorize replacing the approved #39 shell or tokens.

## Navigation

Settings gains a concise `Command access` row with the current authentication status. It opens the SAME existing destination under Advanced settings, without a second form or authority. Advanced settings retains its existing entry. Party & Command retains endpoint editing and protected change-Command flow. No other settings, diagnostics, reporting, adaptive storage, Sync, alerts or SOS controls move.

## Operator journey and exact labels

1. Android: open `Settings → Command access → Set up Command access`. The setup page says: `On the Command computer, open http://127.0.0.1:8081 → Phone controls.` This is the local browser console; the Android network destination remains the configured Command LAN address on port 8080.
2. `Compare identities`: display `This phone ID` with its full installation UUID and `Copy phone ID`. On Command, select the intended phone and compare its full phone UUID directly. Names and IPs cannot substitute for this check.
3. Command Phone controls displays `This Command ID` and `Copy Command ID` in a compact identity disclosure. Helper: `Public identity of this Command installation. An address or matching ID alone does not authorize control.` Generate only after existing confirmation: `Enroll remote control` / `Replace credential`. Replacement warning and revocation semantics remain intact.
4. Android setup: `Private enrollment credential` (masked, no saved-instance state/autofill/export), followed by `Review authorization`. Parse using existing credential parser and validate this phone UUID before proceeding. Review shows the public `Command ID from credential` and phone ID, never the credential. Say: `Compare this Command ID with Phone controls on the Command computer. Transfer credentials privately.` Buttons: `Cancel`, `Authorize Command`. Existing explicit permission scope is retained: reporting, adaptive persistence, Sync, alerts and OS-permitted tracking controls. Authority changes retain existing protected re-enrollment boundary.
5. After authorization: `Credential enrolled` / `Waiting for authenticated contact`. Use the existing outbound control exchange; no new handshake, auto-pairing, listener or mandatory test command. Explain how existing tracking/sender operation obtains contact without silently starting tracking. Success becomes `Contact verified` only after signature, target, enrollment, authority, nonce and freshness checks pass for the current binding.

## Status contract

| State | Main copy | Evidence / action |
|---|---|---|
| Fresh install | Not enrolled | Set up Command access |
| Saved credential | Credential enrolled | Waiting for authenticated contact; View setup steps |
| Verified | Contact verified | Exact last-success UTC timestamp and age; View verification details |
| Stale/offline | Contact unavailable | Preserve last verified timestamp; current contact unavailable |
| Invalid signature/authority | Authentication failed | Show canonical reason contextually; Review enrollment. Do not claim revocation or an authority mismatch unless evidenced |
| Locally disabled | Disabled on this phone | Explicit local state; Authorize Command; pending results retained |
| Command revoked | Revoked on this Command (Command only) | Android says authentication denied/unavailable unless it has authenticated revocation evidence |

### Verified-contact freshness

A qualifying contact is an actual response to the current outbound authenticated control exchange, accepted by the existing verifier after checking protocol/envelope structure, MAC, phone target, enrollment, persistent authority UUID, request nonce/correlation and protocol timestamp freshness. The current endpoint generation and authorization binding must still match when evidence is committed. Empty authenticated polls qualify; receiving or executing an instruction is not required. Failed or rejected responses never refresh this evidence.

Record the local receipt UTC timestamp for display and a monotonic receipt instant for live age. Proposed UI rule: the compact `Contact verified` label means a qualifying response was received less than 30 seconds ago in the current process and binding, with no subsequent failed exchange, local disable or binding change. Show `Last verified response: <UTC> · <age> ago`; this is recent response evidence, not a guarantee of continuous connectivity or instruction execution. At 30 seconds without another accepted response, show `Contact unavailable` with `Previously verified. Waiting to reconnect.`; details identify the evidence as stale, even if GNSS delivery continues. A failed exchange immediately removes the current verified state: authentication rejection shows `Authentication failed`; transport failure shows `Authenticated contact unavailable`, retaining the last-success time. Do not claim offline network status from authentication rejection alone.

The 30-second UI window is a proposed conservative presentation threshold consistent with current Command Phone controls, not a new protocol expiry or polling requirement. Before implementation, verify sender scheduling and expected polling gaps; if the window needs adjustment, record the rule for operator review rather than silently prolonging verified status. No additional polling engine or forced tracking start is authorized.

Enrollment, configured address, Wi-Fi, ordinary GNSS ACKs and retained instruction/result history NEVER establish current connectivity. After recreation within the same process, reuse only valid current typed evidence; after process restart, show `Current contact unconfirmed` until a new qualifying response. Persisted last-success UTC is historical information only; use monotonic time for current-process freshness and handle wall-clock changes without extending the window. Re-enrollment, authority/endpoint generation changes and local disable invalidate current evidence. Retain historical evidence with its original binding so it cannot be attributed to a replacement credential or Command. Never infer credential expiry from command TTL.

Command Phone controls must label its own `last_seen` as the last authenticated phone request accepted by Command. That is independent, directional evidence; it does not prove Android received or verified Command's response. Show `Authenticated phone request received` with timestamp/age, rather than claiming Android-side response verification from this field.

`Identity & verification details` contains full `Authorized Command ID`, `This phone ID`, `Saved Command address`, last verified contact and canonical rejection reason. If only journal evidence exists, label it `Last retained authenticated instruction/result`, not the last successful poll. `Copy Command ID` copies only the persistent authority UUID; `Copy phone ID` copies only the installation UUID. Neither action copies credential text, serialized enrollment data, keys, instruction payloads or a combined identity/credential bundle. Ordinary identity details and diagnostic displays contain no private credential or encrypted credential blob. The masked credential input and existing explicit Command provisioning dialog are the only credential-entry/transfer surfaces; private transfer remains an explicit operator action, separate from all public-ID copy controls. Credential values never enter mockups, accessibility descriptions, logs, diagnostics, public clipboard actions or exports.

## Implementation implications for later approval

Current ControlKeyStore uses existing Android Keystore AES-GCM and private preferences. bind validates target phone; disable clears local enrollment and preserves results. Command Phone controls uses per-phone enrollment and last_seen, with 30-second freshness; last_seen is directional phone-request evidence as specified above. Existing GET /local/control is guarded by loopback peer AND localhost/loopback Host and no-store; mutations additionally require same-origin JSON confirmation. Add only a read-only public authority projection here, using existing persistent state, rather than widening /local/state or exposing the LAN control listener.

Android currently retains instruction/result evidence but not successful empty poll timestamps. A minimal typed evidence projection must be populated at the existing authenticated-success/failure boundaries; retain historical evidence per enrollment/endpoint generation using existing persistence, never a second key store or authentication engine. Distinguish local disable from never enrolled after restart without reconstructing intent from missing credentials. Security failures must not overwrite the prior success timestamp or imply a successful remote action. Endpoint edits/re-enrollment invalidate in-flight evidence.

## Acceptance after approval

Update existing docs/ui-preservation-matrix.md, protocol/security/onboarding owning sections and Android/Command READMEs. Reuse CommandControlTest, CommandConsoleUiTest, SettingsDiagnosticsTest, Go control tests and the actual bridge. Cover public Command-ID versus instruction-ID labels and copy payloads, the 30-second monotonic boundary, clock changes, failed exchanges, process restart, directional contact evidence, UUID mismatch, authority/signature/nonce/freshness, rotation/revocation/re-enrollment, restart/Keystore, empty polls, stale/reconnect, disable and secret redaction. Run exact-source Android tests/lint/APK, Go race/vet, bridge and integrated CI plus native layout/accessibility evidence. No pixel baseline CI. Physical Android and native macOS/Windows verification remain NOT PERFORMED. No implementation tests run for this proposal; no implementation branch or PR created, no merge/issue closure/release.
