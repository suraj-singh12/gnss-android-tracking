GNSS offline map POC (Issue #88) - Gangtok, Sikkim, 20 km radius
==================================================================
Experimental evaluation build. NOT GNSS Command. Works fully offline.

Run (no installation needed):
  macOS (Apple silicon): double-click or run ./open-map-macos-apple-silicon
  macOS (Intel):         ./open-map-macos-intel
  Windows:               double-click open-map-windows.exe
  Linux:                 ./open-map-linux

It serves the "map" folder on http://127.0.0.1:8770 (this computer only) and opens your
browser. Use Chrome, Edge or Firefox with hardware graphics (WebGL). Keep the window open
while testing; close it to stop. Option: --port 8780 if 8770 is busy.

macOS may block the unsigned viewer: right-click it > Open, or run
  xattr -dr com.apple.quarantine <unzipped folder>
Windows SmartScreen may warn: More info > Run anyway.

Try: scroll/pinch to zoom, drag to pan, double-click to zoom in. Start at the overview, then
zoom into the main town, villages, roads, rivers and peaks.

Data: (c) OpenStreetMap contributors (ODbL); Copernicus DEM GLO-30 (c) DLR/Airbus, ESA/EU;
ESA WorldCover 2021 (CC BY 4.0). Software: MapLibre GL JS (BSD-3-Clause), Noto Sans (OFL).
Source: poc/issue-88-offline-map-builder/maplibre on branch devX/issue-88-offline-map-builder-poc.
